import React from 'react';
import Login from './auth/Login';
import Registration from './auth/Registration';
import Home from './components/Page/Home'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

const App = () => {
  return (
    <>
    <Router>
    <Routes>
      <Route path="/"element={<Home/>}/>
    <Route path="/Login" element={<Login />} />
    <Route path="/Registration" element={<Registration />} />


   
      </Routes>
      </Router>

    </>
  );
}

export default App;
