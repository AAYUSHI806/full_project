import { useMutation } from "react-query";
import { Axios } from "../axios/axios";

function handleLogin(user) {
  // console.log(user)

  return Axios.post("/admin_login", user);
}

export default function useLogin() {
  return useMutation(handleLogin);
}
