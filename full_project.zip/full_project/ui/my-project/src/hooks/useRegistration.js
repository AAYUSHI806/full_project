


import { useMutation, useQuery } from "react-query";
import { Axios } from "../axios/axios";

const AddRegistration = async (expertData) => {
  console.log("queryKey--addExpert-", expertData);
  try {
    const formData = new FormData();
    formData.append("first_name", expertData.first_name);
    formData.append("last_name", expertData.last_name);
    formData.append("email_id", expertData.email_id);
    formData.append("password", expertData.password);
    formData.append("gender", expertData.gender);
    formData.append("country", expertData.country);
    formData.append("phone_no", expertData.phone_no);
    formData.append("city", expertData.city);
    formData.append("gender", expertData.gender);
    formData.append("state", expertData.state);
    

    return await Axios.post(`/http://localhost:7272/testing/registration`, formData);
  } catch (err) {
    console.log(err);
  }
};
export function useAddRegistration() {
  return useMutation(AddRegistration);
}
