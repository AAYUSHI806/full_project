// import React from 'react';
// import { Formik, Form, Field, ErrorMessage } from 'formik';
// import * as Yup from 'yup';
// import { Link } from 'react-router-dom';

// const validationSchema = Yup.object({
//   firstName: Yup.string().required('First Name is required'),
//   lastName: Yup.string().required('Last Name is required'),
//   email: Yup.string().email('Invalid email address').required('Email is required'),
//   password: Yup.string().required('Password is required'),
//   mobile: Yup.string().required('Mobile Number is required'),
//   gender: Yup.string().required('Gender is required'),
//   city: Yup.string().required('City is required'),
//   state: Yup.string().required('State is required'),
//   country: Yup.string().required('Country is required'),
// });

// function Registration() {
//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gray-100">
//       <Formik
//         initialValues={{
//           firstName: '',
//           lastName: '',
//           email: '',
//           password: '',
//           mobile: '',
//           countryCode: '+91',
//           gender: '',
//           city: '',
//           state: '',
//           country: '',
//         }}
//         validationSchema={validationSchema}
//         onSubmit={(values, { resetForm }) => {
//           console.log('Form Submitted:', values);
//           resetForm(); // Form fields ko clear karne ke liye resetForm function ka use karein
//         }}
//       >
//         {() => (
//           <Form className="bg-white p-6 rounded shadow-md w-full max-w-lg">
//             <h2 className="text-2xl font-bold mb-5">Registration Form</h2>

//             <div className="mb-4 flex justify-between">
//               <div className="w-1/2 mr-2">
//                 <label className="block text-gray-700">First Name</label>
//                 <Field
//                   type="text"
//                   name="firstName"
//                   className="mt-1 p-2 w-full border rounded"
//                 />
//                 <ErrorMessage name="firstName" component="p" className="text-red text-sm" />
//               </div>
//               <div className="w-1/2">
//                 <label className="block text-gray-700">Last Name</label>
//                 <Field
//                   type="text"
//                   name="lastName"
//                   className="mt-1 p-2 w-full border rounded"
//                 />
//                 <ErrorMessage name="lastName" component="p" className="text-red text-sm" />
//               </div>
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Email</label>
//               <Field
//                 type="email"
//                 name="email"
//                 className="mt-1 p-2 w-full border rounded"
//               />
//               <ErrorMessage name="email" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Password</label>
//               <Field
//                 type="password"
//                 name="password"
//                 className="mt-1 p-2 w-full border rounded"
//               />
//               <ErrorMessage name="password" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4 flex justify-between">
//               <Field as="select" name="countryCode" className="mr-2 p-2 border rounded w-1/4">
//                 <option value="+91">+91</option>
//                 <option value="+1">+1</option>
//                 <option value="+44">+44</option>
//               </Field>
//               <Field
//                 type="text"
//                 name="mobile"
//                 className="p-2 w-full border rounded"
//               />
//               <ErrorMessage name="mobile" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Gender</label>
//               <div className="flex">
//                 <label className="mr-4">
//                   <Field
//                     type="radio"
//                     name="gender"
//                     value="male"
//                     className="mr-1"
//                   />
//                   Male
//                 </label>
//                 <label>
//                   <Field
//                     type="radio"
//                     name="gender"
//                     value="female"
//                     className="mr-1"
//                   />
//                   Female
//                 </label>
//               </div>
//               <ErrorMessage name="gender" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4 flex justify-between">
//               <div className="w-1/2 mr-2">
//                 <label className="block text-gray-700">City</label>
//                 <Field as="select" name="city" className="mt-1 p-2 w-full border rounded">
//                   <option value="">Select City</option>
//                   <option value="Mumbai">Mumbai</option>
//                   <option value="Delhi">Delhi</option>
//                   <option value="Bangalore">Bangalore</option>
//                 </Field>
//                 <ErrorMessage name="city" component="p" className="text-red text-sm" />
//               </div>
//               <div className="w-1/2">
//                 <label className="block text-gray-700">State</label>
//                 <Field as="select" name="state" className="mt-1 p-2 w-full border rounded">
//                   <option value="">Select State</option>
//                   <option value="Maharashtra">Maharashtra</option>
//                   <option value="Delhi">Delhi</option>
//                   <option value="Karnataka">Karnataka</option>
//                 </Field>
//                 <ErrorMessage name="state" component="p" className="text-red text-sm" />
//               </div>
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Country</label>
//               <Field as="select" name="country" className="mt-1 p-2 w-full border rounded">
//                 <option value="">Select Country</option>
//                 <option value="India">India</option>
//                 <option value="USA">USA</option>
//                 <option value="UK">UK</option>
//               </Field>
//               <ErrorMessage name="country" component="p" className="text-red text-sm" />
//             </div>

//             <button
//               type="submit"
//               className="w-full bg-primary text-white p-2 rounded hover:bg-blue-700 transition-colors"
//             >
//               Submit
//             </button>

//             <div className="mt-4 text-center">
//               Already have an account?{' '}
//               <Link to="/Login" className="text-blue hover:underline">
//                 Login
//               </Link>
//             </div>
//           </Form>
//         )}
//       </Formik>
//     </div>
//   );
// }

// export default Registration;


import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Link } from 'react-router-dom';
import {useAddRegistration} from "../hooks/useRegistration";

const validationSchema = Yup.object({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().required('Password is required'),
  mobile: Yup.string().required('Mobile Number is required'),
  gender: Yup.string().required('Gender is required'),
  city: Yup.string().required('City is required'),
  state: Yup.string().required('State is required'),
  country: Yup.string().required('Country is required'),
});






function Registration() {
  // const handleSubmit = async (values, { resetForm }) => {
  //   try {
  //     const response = await axios.post('http://localhost:7272/testing/registration', values);
  //     console.log('Form Submitted:', response.data);
  //     resetForm(); 
  //   } catch (error) {
  //     console.error('Error submitting form:', error);
  //   }
  // };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Formik
        initialValues={{
          firstName: '',
          lastName: '',
          email: '',
          password: '',
          mobile: '',
          countryCode: '+91',
          gender: '',
          city: '',
          state: '',
          country: '',
        }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {() => (
          <Form className="bg-white p-6 rounded shadow-md w-full max-w-lg">
            <h2 className="text-2xl font-bold mb-5">Registration Form</h2>

            <div className="mb-4 flex justify-between">
              <div className="w-1/2 mr-2">
                <label className="block text-gray-700">First Name</label>
                <Field
                  type="text"
                  name="firstName"
                  className="mt-1 p-2 w-full border rounded"
                />
                <ErrorMessage name="firstName" component="p" className="text-red text-sm" />
              </div>
              <div className="w-1/2">
                <label className="block text-gray-700">Last Name</label>
                <Field
                  type="text"
                  name="lastName"
                  className="mt-1 p-2 w-full border rounded"
                />
                <ErrorMessage name="lastName" component="p" className="text-red text-sm" />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Email</label>
              <Field
                type="email"
                name="email"
                className="mt-1 p-2 w-full border rounded"
              />
              <ErrorMessage name="email" component="p" className="text-red text-sm" />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Password</label>
              <Field
                type="password"
                name="password"
                className="mt-1 p-2 w-full border rounded"
              />
              <ErrorMessage name="password" component="p" className="text-red text-sm" />
            </div>

            <div className="mb-4 flex justify-between">
              <Field as="select" name="countryCode" className="mr-2 p-2 border rounded w-1/4">
                <option value="+91">+91</option>
                <option value="+1">+1</option>
                <option value="+44">+44</option>
              </Field>
              <Field
                type="text"
                name="mobile"
                className="p-2 w-full border rounded"
              />
              <ErrorMessage name="mobile" component="p" className="text-red text-sm" />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Gender</label>
              <div className="flex">
                <label className="mr-4">
                  <Field
                    type="radio"
                    name="gender"
                    value="male"
                    className="mr-1"
                  />
                  Male
                </label>
                <label>
                  <Field
                    type="radio"
                    name="gender"
                    value="female"
                    className="mr-1"
                  />
                  Female
                </label>
              </div>
              <ErrorMessage name="gender" component="p" className="text-red text-sm" />
            </div>

            <div className="mb-4 flex justify-between">
              <div className="w-1/2 mr-2">
                <label className="block text-gray-700">City</label>
                <Field as="select" name="city" className="mt-1 p-2 w-full border rounded">
                  <option value="">Select City</option>
                  <option value="Mumbai">Mumbai</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Bangalore">Bangalore</option>
                </Field>
                <ErrorMessage name="city" component="p" className="text-red text-sm" />
              </div>
              <div className="w-1/2">
                <label className="block text-gray-700">State</label>
                <Field as="select" name="state" className="mt-1 p-2 w-full border rounded">
                  <option value="">Select State</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Karnataka">Karnataka</option>
                </Field>
                <ErrorMessage name="state" component="p" className="text-red text-sm" />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Country</label>
              <Field as="select" name="country" className="mt-1 p-2 w-full border rounded">
                <option value="">Select Country</option>
                <option value="India">India</option>
                <option value="USA">USA</option>
                <option value="UK">UK</option>
              </Field>
              <ErrorMessage name="country" component="p" className="text-red text-sm" />
            </div>

            <button
              type="submit"
              className="w-full bg-primary text-white p-2 rounded hover:bg-blue-700 transition-colors"
            >
              Submit
            </button>

            <div className="mt-4 text-center">
              Already have an account?{' '}
              <Link to="/Login" className="text-blue hover:underline">
                Login
              </Link>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default Registration;





// import React, { useState, useEffect } from 'react';
// import { Formik, Form, Field, ErrorMessage } from 'formik';
// import * as Yup from 'yup';
// import { Link } from 'react-router-dom';
// import axios from 'axios';

// const validationSchema = Yup.object({
//   firstName: Yup.string().required('First Name is required'),
//   lastName: Yup.string().required('Last Name is required'),
//   email: Yup.string().email('Invalid email address').required('Email is required'),
//   password: Yup.string().required('Password is required'),
//   mobile: Yup.string().required('Mobile Number is required'),
//   gender: Yup.string().required('Gender is required'),
//   city: Yup.string().required('City is required'),
//   state: Yup.string().required('State is required'),
//   country: Yup.string().required('Country is required'),
// });

// function Registration() {
//   const [submitStatus, setSubmitStatus] = useState('');
  
//   useEffect(() => {
//     document.title = 'Registration Form';
   
//     return () => {
//       document.title = 'React App';
//     };
//   }, []); 

//   const onSubmit = async (values, { resetForm }) => {
//     console.log('Form Data', values);
//     setSubmitStatus('Submitting...');
    
//     const formData = new FormData();
//     formData.append('first_name', values.firstName);
//     formData.append('last_name', values.lastName);
//     formData.append('email_id', values.email);
//     formData.append('password', values.password);
//     formData.append('gender', values.gender);
//     formData.append('city', values.city);
//     formData.append('state', values.state);
//     formData.append('country', values.country);
//     formData.append('phone_no', values.mobile);
    
//     try {
//       const response = await axios.post('http://localhost:7272/testing/registration', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data'
//         }
//       });
//       console.log('Response', response);
//       setSubmitStatus('Form submitted successfully!');
//     } catch (error) {
//       console.error('Error:', error);
//       setSubmitStatus('An error occurred. Please try again.');
//     }
//     resetForm();
//   };

//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gray-100">
//       <Formik
//         initialValues={{
//           firstName: '',
//           lastName: '',
//           email: '',
//           password: '',
//           mobile: '',
//           countryCode: '+91',
//           gender: '',
//           city: '',
//           state: '',
//           country: '',
//         }}
//         validationSchema={validationSchema}
//         onSubmit={onSubmit}
//       >
//         {({ resetForm }) => (
//           <Form className="bg-white p-6 rounded shadow-md w-full max-w-lg">
//             <h2 className="text-2xl font-bold mb-5">Registration Form</h2>

//             <div className="mb-4 flex justify-between">
//               <div className="w-1/2 mr-2">
//                 <label className="block text-gray-700">First Name</label>
//                 <Field
//                   type="text"
//                   name="firstName"
//                   className="mt-1 p-2 w-full border rounded"
//                 />
//                 <ErrorMessage name="firstName" component="p" className="text-red text-sm" />
//               </div>
//               <div className="w-1/2">
//                 <label className="block text-gray-700">Last Name</label>
//                 <Field
//                   type="text"
//                   name="lastName"
//                   className="mt-1 p-2 w-full border rounded"
//                 />
//                 <ErrorMessage name="lastName" component="p" className="text-red text-sm" />
//               </div>
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Email</label>
//               <Field
//                 type="email"
//                 name="email"
//                 className="mt-1 p-2 w-full border rounded"
//               />
//               <ErrorMessage name="email" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Password</label>
//               <Field
//                 type="password"
//                 name="password"
//                 className="mt-1 p-2 w-full border rounded"
//               />
//               <ErrorMessage name="password" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4 flex justify-between">
//               <Field as="select" name="countryCode" className="mr-2 p-2 border rounded w-1/4">
//                 <option value="+91">+91</option>
//                 <option value="+1">+1</option>
//                 <option value="+44">+44</option>
//               </Field>
//               <Field
//                 type="text"
//                 name="mobile"
//                 className="p-2 w-full border rounded"
//               />
//               <ErrorMessage name="mobile" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Gender</label>
//               <div className="flex">
//                 <label className="mr-4">
//                   <Field
//                     type="radio"
//                     name="gender"
//                     value="male"
//                     className="mr-1"
//                   />
//                   Male
//                 </label>
//                 <label>
//                   <Field
//                     type="radio"
//                     name="gender"
//                     value="female"
//                     className="mr-1"
//                   />
//                   Female
//                 </label>
//               </div>
//               <ErrorMessage name="gender" component="p" className="text-red text-sm" />
//             </div>

//             <div className="mb-4 flex justify-between">
//               <div className="w-1/2 mr-2">
//                 <label className="block text-gray-700">City</label>
//                 <Field as="select" name="city" className="mt-1 p-2 w-full border rounded">
//                   <option value="">Select City</option>
//                   <option value="Mumbai">Mumbai</option>
//                   <option value="Delhi">Delhi</option>
//                   <option value="Bangalore">Bangalore</option>
//                 </Field>
//                 <ErrorMessage name="city" component="p" className="text-red text-sm" />
//               </div>
//               <div className="w-1/2">
//                 <label className="block text-gray-700">State</label>
//                 <Field as="select" name="state" className="mt-1 p-2 w-full border rounded">
//                   <option value="">Select State</option>
//                   <option value="Maharashtra">Maharashtra</option>
//                   <option value="Delhi">Delhi</option>
//                   <option value="Karnataka">Karnataka</option>
//                 </Field>
//                 <ErrorMessage name="state" component="p" className="text-red text-sm" />
//               </div>
//             </div>

//             <div className="mb-4">
//               <label className="block text-gray-700">Country</label>
//               <Field as="select" name="country" className="mt-1 p-2 w-full border rounded">
//                 <option value="">Select Country</option>
//                 <option value="India">India</option>
//                 <option value="USA">USA</option>
//                 <option value="UK">UK</option>
//               </Field>
//               <ErrorMessage name="country" component="p" className="text-red text-sm" />
//             </div>

//             <button
//               type="submit"
//               className="w-full bg-primary text-white p-2 rounded hover:bg-blue-700 transition-colors"
//             >
//               Submit
//             </button>

//             {submitStatus && (
//               <div className="mt-4 text-center text-blue-600">{submitStatus}</div>
//             )}

//             <div className="mt-4 text-center">
//               Already have an account?{' '}
//               <Link to="/Login" className="text-blue hover:underline">
//                 Login
//               </Link>
//             </div>
//           </Form>
//         )}
//       </Formik>
//     </div>
//   );
// }

// export default Registration;
