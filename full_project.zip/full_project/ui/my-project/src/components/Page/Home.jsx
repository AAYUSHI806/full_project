import React from 'react'

const Home = () => {
  return (
    <div className='text-22 font-bold'>
      Home
    </div>
  )
}

export default Home
