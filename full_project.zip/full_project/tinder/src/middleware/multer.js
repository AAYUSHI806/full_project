// const multer = require("multer");
// const path = require("path");
// const fs = require("fs");
// const fileStorage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     let uploadPath = ""; // Define the upload path

//     if (file.fieldname === "profile_image") {
//       uploadPath = path.join(__dirname, "../../public/profile_image");
//     }
//     else if (file.fieldname === "blogImg") {
//       uploadPath = path.join(__dirname,  "../../public/blog_image");
//     }
//     else if (file.fieldname === "videoFile") {
//       uploadPath = path.join(__dirname,  "../../public/videos");
//     }
//     else if (file.fieldname === 'storieVideoFile') {
//       uploadPath = path.join(__dirname, '../../public/stories');
//     }
//     else if (file.fieldname === 'storyImg') {
//       uploadPath = path.join(__dirname, '../../public/stories/story_images');
//     }
//     else if (file.fieldname === 'exercise_image') {
//       uploadPath = path.join(__dirname, '../../public/exercise_image');
//     }
//   else {
//       console.log(`multer problem ${file.fieldname}`);
//       return cb(new Error("Invalid fieldname"));
//     }

//     // Use fs module to create the folder
//     fs.mkdir(uploadPath, { recursive: true }, (err) => {
//       if (err) {
//         console.error("Error creating folder:", err);
//         return cb(err);
//       }
//       cb(null, uploadPath);
//     });
//   },
//   filename: (req, file, cb) => {
//     cb(
//       null,
//       `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`
//     );
//   },
// });

// const uploads = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 5000000, // 5000000 Bytes = 5 MB
//   },
//   fileFilter(req, file, cb) {
//     if (!file.originalname.match(/\.(png|jpg|jpeg|doc|docx|pdf|txt|xls|xlsx|ppt|pptx)$/)) {
//       // upload only png and jpg format
//       return cb(new Error("Please upload an Image"));
//     }
//     cb(null, true);
//   },
// });

// // Set up Multer with the storage configuration and file size limit
// const upload_video = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 15000000, // 5000000 Bytes = 5 MB
//   },
//   fileFilter: (req, file, cb) => {
//     // Validate file type
//     if (file.fieldname === 'videoFile' && file.mimetype.match(/video\/(mp4|MPEG-4|mkv)/)) {
//       cb(null, true);
//     } else if (file.fieldname === 'blogImg' && file.mimetype.match(/(png|jpg|jpeg|doc|docx|pdf|txt|xls|xlsx|ppt|pptx)/)) {
//       cb(null, true);
//     } else {
//       cb(new Error('Invalid file type. Only MP4, MPEG-4, MKV videos and PNG, JPG, JPEG, DOC, DOCX, PDF files are allowed.'));
//     }
//   },
//   // fileFilter(req, file, cb) {
//   //   if (!file.originalname.match(/\.(mp4|MPEG|mkv)$/)) {
//   //     // upload only png and jpg format
//   //     return cb(new Error("Please upload an video"));
//   //   }
//   //   cb(null, true);
//   // },
// });

// const upload_story = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 15000000, // 5000000 Bytes = 15 MB
//   },
//   fileFilter: (req, file, cb) => {
//     // Validate file type
//     if (file.fieldname === 'storieVideoFile' && file.mimetype.match(/video\/(mp4|MPEG-4|mkv)/)) {
//       cb(null, true);
//     } else if (file.fieldname === 'storyImg' && file.mimetype.match(/(png|jpg|jpeg|doc|docx|pdf|txt|xls|xlsx|ppt|pptx)/)) {
//       cb(null, true);
//     } else {
//       cb(new Error('Invalid file type. Only MP4, MPEG-4, MKV videos and PNG, JPG, JPEG, DOC, DOCX, PDF files are allowed.'));
//     }
//   },
// });

// module.exports = { uploads ,upload_video,upload_story};

const multer = require("multer");
const path = require("path");
const fs = require("fs");

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = ""; // Define the upload path

    switch (file.fieldname) {
      case "profile_image":
        uploadPath = path.join(__dirname, "../../public/profile_image");
        break;
      
      // case "blogImg":
      //   uploadPath = path.join(__dirname, "../../public/blog_image");
      //   break;
      // case "videoFile":
      //   uploadPath = path.join(__dirname, "../../public/videos");
      //   break;
      // case "exercise_image":
      //   uploadPath = path.join(__dirname, "../../public/exercise_image");
      //   break;
      default:
        console.log(`multer problem ${file.fieldname}`);
        return cb(new Error("Invalid fieldname"));
    }

    // Use fs module to create the folder
    fs.mkdir(uploadPath, { recursive: true }, (err) => {
      if (err) {
        console.error("Error creating folder:", err);
        return cb(err);
      }
      cb(null, uploadPath);
    });
  },
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
  },
});

const allowedImageTypes = /\.(png|jpg|jpeg|doc|docx|pdf|txt|xls|xlsx|ppt|pptx)$/;
const allowedVideoTypes = /video\/(mp4|mpeg-4|mkv)/;

const uploads = multer({
  storage: fileStorage,
  limits: {
    fileSize: 5000000, // 5 MB
  },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.match(allowedImageTypes)) {
      return cb(new Error("Please upload an image or document with valid formats."));
    }
    cb(null, true);
  },
});

// const upload_video = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 15000000, // 15 MB
//   },
//   fileFilter: (req, file, cb) => {
//     if (file.fieldname === 'videoFile' && file.mimetype.match(allowedVideoTypes)) {
//       cb(null, true);
//     } else if (file.fieldname === 'blogImg' && file.originalname.match(allowedImageTypes)) {
//       cb(null, true);
//     } else {
//       cb(new Error('Invalid file type. Only MP4, MPEG-4, MKV videos and PNG, JPG, JPEG, DOC, DOCX, PDF files are allowed.'));
//     }
//   },
// });

// const upload_story = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 15000000, // 15 MB
//   },
//   fileFilter: (req, file, cb) => {
//     if (file.fieldname === 'storieVideoFile' && file.mimetype.match(allowedVideoTypes)) {
//       cb(null, true);
//     } else if (file.fieldname === 'storyImg' && file.originalname.match(allowedImageTypes)) {
//       cb(null, true);
//     } else {
//       cb(new Error('Invalid file type. Only MP4, MPEG-4, MKV videos and PNG, JPG, JPEG, DOC, DOCX, PDF files are allowed.'));
//     }
//   },
// });

module.exports = { uploads,
  //  upload_video,
  //   upload_story 
  };
