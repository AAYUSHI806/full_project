const db = require("../../config/config");
const User = db.user;
const bcrypt = require("bcryptjs");
const tokenProcess = require("../services/genrateToken");

exports.admin_login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Trimmed fields
        const trimmedEmail = email ? email.trim() : '';
        const trimmedPassword = password ? password.trim() : '';

        // Simple validation
        if (!trimmedEmail || !trimmedPassword) {
            return res.status(400).json({
                status: false,
                message: "Please provide both email and password",
            });
        }

        const user = await User.findOne({ where: { email_id: trimmedEmail } });

        if (!user) {
            return res.status(401).json({
                status: false,
                message: "Login failed, please check the email address and user type.",
            });
        }

        const passwordIsValid = await bcrypt.compare(trimmedPassword, user.password);
        if (!passwordIsValid) {
            return res.status(401).json({
                status: false,
                message: "Login failed, invalid email or password.",
            });
        }

        const access_token = tokenProcess.generateAccessToken(user);
        const refresh_token = tokenProcess.generateRefreshToken();
        const refreshTokenExpiration = Date.now() + 7 * 24 * 60 * 60 * 1000;

        user.refreshToken = refresh_token;
        user.refreshToken_Expiration = refreshTokenExpiration;
        user.is_verify = 1; // Ensure this field exists and is used correctly
        await user.save();

        res.cookie("refresh_token", refresh_token, { httpOnly: true });

        return res.status(200).json({
            status: true,
            message: "Login successful",
            data: user,
            access_token: access_token
        });
    } catch (error) {
        console.error("Login error:", error);
        return res.status(500).json({
            status: false,
            message: "An error occurred during the login process",
        });
    }
};
