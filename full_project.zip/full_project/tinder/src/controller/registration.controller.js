const db = require("../../config/config")
const user = db.user
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const secret_key = process.env.SECRET_KEY
const emailService = require("../services/emailServices")
const user_registration = async (req, res) => {
  try {

    const { first_name,last_name,country,city,state,phone_no, email_id, password,gender } = req.body;

    // Check if any of the fields are empty
    const isEmptyKey = Object.values(req.body).some(value => !value);

    if (isEmptyKey) {
      return res
        .status(400) // Changed status code to 400 for bad request
        .json({ status: false, message: "Please do not leave empty fields" });
    }

    // Generate OTP for registration
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    // Trimmed fields
    // const trimmedEmail = email_id.trim();
    // const trimmedName = name.trim();
    // const trimmedPassword = password.trim();

    // Check if the email already exists in the database
    const existingUser = await user.findOne({
      where: { email_id: email_id },
    });

    if (existingUser) {
      return res
        .status(400)
        .json({ status: false, message: "Email already exists" });
    }

    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create the new user
    const newUser = await user.create({
      last_name: last_name,
      first_name:first_name,
      country:country,
      city:city,
      state:state,
      phone_no:phone_no,
      password: hashedPassword,
      email_id: email_id,
      gender:gender,

      remember_token: jwt.sign({ email_id: email_id }, secret_key, {
        expiresIn: "7d",
      }),
      otp: otp,
    });

    // Handle profile image upload if it exists
    if (req.file) {
      const filePath = `profile_image/${req.file.filename}`;
      newUser.profile_image = filePath;
      await newUser.save();
    }

    // Send OTP email
    const yourName = first_name;
    const yourCompany = "datting_app";
    const yourPosition = 'datting Manager';
    const emailSent = await emailService(
      otp,
      yourName,
      email_id,
      yourName,
      yourCompany,
      yourPosition
    );

    if (emailSent) {
      return res.status(200).json({
        status: true,
        message: "Registration successful, OTP sent to your registered email for verification.",
        data: newUser,
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Failed to send OTP email. Please try again.",
      });
    }
    
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: false, message: error.message });
  }
};


  module.exports = { 
    user_registration
  }