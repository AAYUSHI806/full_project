// models/User.js
module.exports = (sequelize, DataTypes) => {
    const user = sequelize.define('user', {
      id: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true
      },
      gender:{
        type: DataTypes.ENUM,
        values: [ "male" , "femail", "other" ],
        allowNull: true,
        // defaultValue: "student"
      }, 
      first_name: {
        type: DataTypes.STRING,
        allowNull: true
      },
      last_name: {
        type: DataTypes.STRING,
        allowNull: true
      },
      phone_no: {
        type: DataTypes.STRING,
        allowNull: true
      },
      country: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      city: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      state: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      email_id: {
        type: DataTypes.STRING,
        allowNull: false
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false
      },
      language: {
        type: DataTypes.STRING,
      },
      profile_image: {
        type: DataTypes.STRING,
      },
      otp: {
        type: DataTypes.STRING,
      },
      otp_verify: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0,
      },
      is_verify: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0
      },
      status: {
        type: DataTypes.ENUM,
        values: ["verified", "rejected", "suspended"],
        allowNull: false,
        defaultValue: "verified"
      },
  
      notification: {
        type: DataTypes.BOOLEAN,
      },
      device_id: {
        type: DataTypes.STRING,
      },
      login_from: {
        type: DataTypes.STRING,
      },
      device_token: {
        type: DataTypes.STRING,
      },
      follow_count: {
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      remember_token: {
        type: DataTypes.STRING,
      },
      refreshToken: {
        type: DataTypes.STRING,
        allowNull: true
      },
      refreshToken_Expiration: {
        type: DataTypes.STRING,
        allowNull: true
      },
      is_public : {
        type : DataTypes.BOOLEAN,
        defaultValue : true
      },
      is_active : {
        type : DataTypes.BOOLEAN,
        defaultValue : true
      }
    }, 
    );
  
    return user;
  }