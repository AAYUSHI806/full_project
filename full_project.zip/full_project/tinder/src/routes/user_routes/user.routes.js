const express = require("express")

const router = express.Router()
const { authorize } = require('../../middleware/authorization')

const {uploads} = require("../../middleware/multer")

const { user_registration } = require("../../controller/registration.controller")
const {admin_login}= require("../../controller/login.controller")
const {refresh_token} = require("../../services/refreshToken")

router.post("/registration",uploads.single("profile_image"),user_registration)
router.post("/refresh_token",uploads.none(),refresh_token)
router.post("/login",authorize(['admin']),uploads.none(),admin_login)
module.exports = router