require('dotenv').config()
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const cors = require("cors");
const path = require('path');


const app = express()

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public" )));
app.use(cookieParser());

app.use(cors({
    credentials: true,
    origin : "*",
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    allowedHeaders: 'Content-Type,Authorization'
}));

const mainRoutes = require("./src/routes/main.routes")

app.use("/testing",mainRoutes)

app.get("/",(req,res)=>{
    res.send("Hello dating_yalla_app, Server  is running on port : 7272")
})

app.listen(process.env.PORT,()=>{
    console.log(`Server is running for dating_yalla_app at 7272`);
})