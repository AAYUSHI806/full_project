require('dotenv').config()
const { DB_HOST, DB_NAME, DB_USERNAME, DB_PASSWORD } = process.env
const { Sequelize, DataTypes } = require('sequelize')

const sequelize = new Sequelize(DB_NAME, DB_USERNAME, DB_PASSWORD, {
    host: DB_HOST,
    dialect: 'mysql',
    logging: false,
    
})

try {
    sequelize.authenticate()
    console.log("Connection has been establised successfully with DataBase...!")
} catch (error) {
    console.error("Unable to connect to the database", error)
}

const db = {}
db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.sequelize.sync({alter:true});

db.user = require("../src/model/user_model/registration.model")(sequelize,DataTypes)
// //coupon has One to Many relation with coupon_assign
// db.coupon.hasMany(db.coupon_assign, {
//     forienKey : "couponId",
//     as : "coupon_assign"
// })
// db.coupon_assign.belongsTo(db.coupon, {
//     forienKey : "couponId",
//     as : "coupon" 
// })
module.exports = db;
